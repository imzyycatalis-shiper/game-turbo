package com.imzyyknox.gameturbo;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.view.Gravity;
import android.view.ViewGroup;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(5,12,20));
        getWindow().setNavigationBarColor(Color.rgb(5,12,20));
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setBackgroundColor(Color.rgb(5,12,20));
        TextView title = new TextView(this);
        title.setText("IMZYY KNOX • GAME TURBO");
        title.setTextColor(Color.CYAN); title.setTextSize(16); title.setPadding(18,12,18,12);
        Button floating = new Button(this); floating.setText("ENABLE FLOATING GAME PANEL");
        floating.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()));
                startActivity(i);
            } else startService(new Intent(this, FloatingService.class));
        });
        WebView web = new WebView(this);
        WebSettings s = web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(true);
        web.setWebViewClient(new WebViewClient());
        web.loadUrl("file:///android_asset/index.html");
        layout.addView(title);
        layout.addView(floating, new LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT));
        layout.addView(web, new LinearLayout.LayoutParams(-1,0,1));
        setContentView(layout);
    }
}
