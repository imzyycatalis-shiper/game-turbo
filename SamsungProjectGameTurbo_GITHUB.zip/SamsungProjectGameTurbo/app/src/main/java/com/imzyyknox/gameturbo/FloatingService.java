package com.imzyyknox.gameturbo;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.io.File;

public class FloatingService extends Service {
    private WindowManager wm;
    private View panel;
    private WindowManager.LayoutParams params;
    private TextView bubble;

    @Override public void onCreate() {
        super.onCreate();
        startForeground(7, notification());
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        showBubble();
    }
    private Notification notification() {
        String channel = "imzyy_turbo";
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(channel,"Game Turbo Panel",NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
        return new Notification.Builder(this, channel).setContentTitle("IMZYY KNOX Game Turbo")
            .setContentText("Floating tools panel is active").setSmallIcon(android.R.drawable.ic_menu_manage).build();
    }
    private WindowManager.LayoutParams lp(int w,int h) {
        return new WindowManager.LayoutParams(w,h, Build.VERSION.SDK_INT>=26 ?
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
    }
    private void showBubble() {
        bubble = new TextView(this); bubble.setText("⚡"); bubble.setTextSize(25); bubble.setTextColor(Color.CYAN);
        bubble.setGravity(Gravity.CENTER); bubble.setBackgroundColor(Color.rgb(10,30,45)); bubble.setPadding(14,8,14,8);
        params = lp(-2,-2); params.gravity=Gravity.TOP|Gravity.START; params.x=30; params.y=240;
        bubble.setOnClickListener(v -> showPanel());
        bubble.setOnTouchListener(new View.OnTouchListener() {
            int sx,sy; float tx,ty;
            public boolean onTouch(View v, android.view.MotionEvent e) {
                if(e.getAction()==0){sx=params.x;sy=params.y;tx=e.getRawX();ty=e.getRawY();return false;}
                if(e.getAction()==2){params.x=sx+(int)(e.getRawX()-tx);params.y=sy+(int)(e.getRawY()-ty);wm.updateViewLayout(bubble,params);return true;}
                return false;
            }
        });
        wm.addView(bubble,params);
    }
    private void showPanel() {
        if(panel!=null){try{wm.removeView(panel);}catch(Exception ignored){}}
        LinearLayout box=new LinearLayout(this); box.setOrientation(1); box.setPadding(18,14,18,14); box.setBackgroundColor(Color.rgb(8,20,32));
        TextView head=new TextView(this); head.setText("IMZYY KNOX  •  GAME TURBO"); head.setTextColor(Color.CYAN); head.setTextSize(15); head.setTypeface(null,Typeface.BOLD); box.addView(head);
        TextView note=new TextView(this); note.setText("Quick tools • Android permission limits apply"); note.setTextColor(Color.LTGRAY); box.addView(note);
        addButton(box,"OPEN GAME TURBO",()->{Intent i=new Intent(this,MainActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);});
        addButton(box,"CLEAR THIS APP CACHE",()->{long before=size(getCacheDir()); delete(getCacheDir()); Toast.makeText(this,"App cache cleared: "+(before/1024)+" KB",Toast.LENGTH_LONG).show();});
        addButton(box,"DISPLAY SETTINGS",()->openSettings(Settings.ACTION_DISPLAY_SETTINGS));
        addButton(box,"BATTERY SETTINGS",()->openSettings(Settings.ACTION_BATTERY_SAVER_SETTINGS));
        addButton(box,"APP INFO / PERMISSIONS",()->{Intent i=new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,android.net.Uri.parse("package:"+getPackageName()));i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);});
        addButton(box,"CLOSE PANEL",()->{try{wm.removeView(panel);panel=null;}catch(Exception ignored){}});
        panel=box; WindowManager.LayoutParams p=lp(-2,-2);p.gravity=Gravity.TOP|Gravity.END;p.x=18;p.y=180;wm.addView(panel,p);
    }
    private void addButton(LinearLayout box,String text,Runnable r){Button b=new Button(this);b.setText(text);b.setOnClickListener(v->r.run());box.addView(b);}
    private void openSettings(String action){try{Intent i=new Intent(action);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);}catch(Exception e){Toast.makeText(this,"Setting not available on this device",Toast.LENGTH_SHORT).show();}}
    private long size(File f){if(!f.exists())return 0;if(f.isFile())return f.length();long n=0;File[] a=f.listFiles();if(a!=null)for(File x:a)n+=size(x);return n;}
    private void delete(File f){if(!f.exists())return;if(f.isDirectory()){File[] a=f.listFiles();if(a!=null)for(File x:a)delete(x);}if(!f.equals(getCacheDir()))f.delete();}
    @Override public int onStartCommand(Intent i,int flags,int id){return START_STICKY;}
    @Override public void onDestroy(){if(bubble!=null)wm.removeView(bubble);if(panel!=null)wm.removeView(panel);super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
}
