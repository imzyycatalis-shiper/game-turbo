# SAMSUNG PROJECT GAME TURBO — IMZYY KNOX

Android Studio project (Java + WebView) wrapping the previous dashboard and adding a draggable floating tools panel.

## Build
1. Open this folder in Android Studio (JDK 17; Android SDK Platform 35).
2. Allow Gradle sync.
3. Build > Build APK(s), or run on a Samsung device.
4. On first launch, tap ENABLE FLOATING GAME PANEL and grant "Display over other apps".

## Important Android limitations
- The overlay is a quick-tools panel, not Samsung Game Booster integration.
- Clear cache only clears this companion app's own cache. Android does not let ordinary apps silently clear another app's cache.
- FPS selector/forcing, CPU/GPU clock, governor, thermal limits and kernel writes require supported system/OEM privileges or root. This project does not fake those operations.
- Display and battery buttons open Android settings; the user chooses settings there.
- Overlay permission must be explicitly granted by the user. Android may restrict foreground-service behavior depending on OS version and OEM policy.
- This is source code, not a signed APK. Build it in Android Studio to generate an installable APK.
